/*
 *     Clase para elegir un tipo de servicio por parte de la barbería
 *     mediante un codigo.
 */
package barberia;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */


public class TipoServicio {
    private int codigo;
    private String descripcion;
    private TipoServicio servicio;
    
    public TipoServicio(int codigo,String descripcion){
        this.codigo = codigo;
        this.descripcion = descripcion;
    }

    TipoServicio(String descripcion) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getDescripcion() {
        return descripcion;
    }
    


    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
    
    public TipoServicio getTipoServicio(){
        return servicio;
    
    }
    
    public void setTipoServicio(int codigo){
        this.codigo = codigo;
    
    }
}
