package barberia;

import java.sql.Time;
import java.util.Date;
import java.util.ArrayList;
import barberia.Cliente;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class Cita {
    //Atributos
    private Date fecha;
    private Time hora;
    private Cliente cliente;
    private TipoServicio tipoServicio;
    
    public Cita( ){
        
    }
}
