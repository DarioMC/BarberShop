/*
 *     Clase para elegir un tipo de servicio por parte de la barbería
 *     mediante un codigo.
 */
package barberia;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class TipoServicio {
    
    //Atributos
    private int codigo;
    private String descripcion;
    private TipoServicio servicio;
    
    // Métodos
    
    // Constructor
    
    TipoServicio(int codigo, String descripcion){
        this.codigo = codigo;
        this.descripcion = descripcion;
    
    
    }
    
    public TipoServicio getTipoServicio(){
        return servicio;
    
    }
    
    public void setTipoServicio(int codigo){
        this.codigo = codigo;
    
    }
    
}