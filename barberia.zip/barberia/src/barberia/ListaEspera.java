/*
 *     Clase que genera la lista de espera de la barbería
 * 
 * 
 */
package barberia;


/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */


import java.util.ArrayList;

/**
 *
 * @author Darío
 */
public class ListaEspera {
    
    // Atributos
    private ArrayList<Cita>citas;
    
    // Métodos
    
    //Contructor
    
    ListaEspera(){
    
    citas = new ArrayList();
    }
    
    public void ToString(){
    
    }
    
}
