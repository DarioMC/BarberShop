package barberia;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class Barberia {
    //Atributos
    private String nombre;
    private String horario;   //  requiere posibles cambios
    private String contrasenia;
    private Cliente cliente;
    
    //Métodos
    
    //Constructor
    Barberia(String nombre,String horario, String contrasenia){
        this.nombre = nombre;
        this.horario = horario;
        this.contrasenia = contrasenia;
    }
    
    public boolean ValidarIngreso(String nombre, String contrasenia){
        boolean bandera = false;
        if(contrasenia == this.contrasenia){ // Si la contraseña ingresada es igual a la de la barberia el valor de bandera cambia a true
            bandera = true;
        }
        return bandera;
    }
    
    public void setContrasenia(String contrasenia) {
        this.contrasenia = contrasenia;
    }
    
    public void crearCliente(){
    
    }
    
    public void modificarCliente(){
    
    }
    public void borrarCliente(){
    
    }
    //public Cliente verCliente(){
        
    //}
    
    public void crearCita(){
    
    }
    
    public void modificarCita(){
    
    }
    public void borrarCita(){
    
    }
    //public Cita verCita(){
    
    //}
    public void enviarNotificaciónCita(){
    
    }
    public void confirmarCita(){
    
    }
    public void verCalendarioCitas(){
    
    }
    public void crearTipoServicio(){
    
    }
    
    public void modificarTipoServicio(){
    
    }
    public void borrarTipoServicio(){
    
    }
    public void verListaEspera(){
    
    }
    public void agregarClienteListaEspera(){
    
    }
    public void borrarClienteListaEspera(){
    
    }
    public void establecerHorario(){

    }
    
    
    
    
    
    
}
