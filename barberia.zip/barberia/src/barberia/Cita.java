package barberia;

import java.sql.Time;
import java.util.Date;
import java.util.ArrayList;
import barberia.Cliente;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class Cita {
    //Atributos
    private int anio;
    private int mes;
    private int dia;
    private int hora;
    private Cliente cliente;
    private TipoServicio tipoServicio;
    
    public Cita(int anio, int mes, int dia, int hora, Cliente cliente, TipoServicio tipoServicio ){
        this.anio = anio;
        this.mes = mes;
        this.dia = dia;
        this.hora = hora;
        this.cliente = cliente;
        this.tipoServicio = tipoServicio;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public int getAnio() {
        return anio;
    }

    public int getMes() {
        return mes;
    }

    public int getDia() {
        return dia;
    }

    public TipoServicio getTipoServicio() {
        return tipoServicio;
    }
    
}
