package barberia;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class Cita {
    //Atributos

    private int codigo;
    private LocalDate fecha;
    private LocalTime hora;
    private int cliente;
    private Cita cita;   // posible modificación
    //private tipoDeServicio;
    
    
    // Métodos
    
    // Constructor
    
    Cita(LocalDate fecha,LocalTime hora, int cliente){ // tipoServicio
    
        this.codigo = codigo;
        this.cliente = cliente;
        this.fecha = fecha;
        this.hora = hora; 
    
    }  
    
    
    public Cita getCita(){
        return cita;
    }
    public void setCita(int codigo){
        this.codigo = codigo;
    
    }
}
