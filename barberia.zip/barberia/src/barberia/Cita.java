package barberia;

/**
 *
 * @author Andrea Abarca
           Darío Monestel
           Jafeth Rivas
 */

public class Cita {
    //Atributos
    
}
