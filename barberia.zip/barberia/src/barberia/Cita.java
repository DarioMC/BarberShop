package barberia;

public class Cita {
    //Atributos
    
}
